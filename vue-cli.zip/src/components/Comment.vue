<template>
    <div class="list">
      <div class="item">
        <div class="photo"><img src="../assets/pf.png" alt="Picture"></div>
        <div class="info">
          <div class="name">  {{ name }} - postado ontem, ás 19h35</div>
            <slot></slot>
          </div>
         
          <!-- <a href="/" class="url_checkout">Responder</a> -->
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import Comment from './NewComment.vue';

export default {
   props: ['comments'],
}
</script>

<style scoped lang="scss">
.comments {
    margin: 30px 200px 0;

    .block-title {
    padding: 25px 0 15px;
    font-family: 'Montserrat';
    font-size: 25px;
    line-height: 1.2;
    text-transform: uppercase;
    border-bottom: 1px solid 
    #e1e1e1;
    margin: 0 0 20px;
    text-align: start;
  }

  .block-description {
    font-family: 'Montserrat';
    font-size: 12px;
    margin: 0 0 40px;
    text-align: start;
  }
}

.form {
  background:#f7f7f7;
  display: flex;
  padding: 20px 15px;
  flex-wrap: wrap;
  margin: 0 0 20px;
  border-radius: 5px;

  p {
    width: 100%;
    padding: 0 5px;
    font-size: 12px;
    color:
    #999;
    margin: 0 0 5px;
  }

  input {
    width: calc(50% - 10px);
    padding: 15px;
    font-family: sans-serif;
    font-size: 12px;
    border: 0;
    margin: 0 5px 10px;
    border-radius: 5px;
  }

  textarea {
    width: calc(75% - 10px);
    height: 45px;
    padding: 15px;
    font-family: sans-serif;
    font-size: 12px;
    border: 0;
    margin: 0 5px;
    border-radius: 5px;
  }

  button {
    background:#333;
    flex-grow: 1;
    font-family: sans-serif;
    font-size: 14px;
    font-weight: bold;
    color:
    #fff;
    text-align: center;
    text-transform: uppercase;
    border: 0;
    margin: 0 5px;
    border-radius: 5px;
    cursor: pointer;
  }
}

.list {
  text-align: start;

  .item {
    display: flex;
    padding: 0 0 25px;
    border-bottom: 1px solid#eee;
    margin: 0 0 25px;

    .photo {
      margin: 0 20px 0 0;
    }

    .info p {
      font-size: 12px;
      color:#666;
      margin: 0;
    }

    .info a {
      font-size: 10px;
      font-weight: bold;
      color:#000;
      text-transform: uppercase;
    }
  }
}

</style>