<template>
    <div class="container mt-5">
      <div class="row">
        <div class="col-8 mx-auto">
          <app-new-comment  @commentAdded="newComment"></app-new-comment>
          <app-comment-grid  :comments="comments"> </app-comment-grid>
        </div>
      </div>
    </div>
</template>

<script>
  import Vue from 'vue'
  import BootstrapVue from 'bootstrap-vue'
  Vue.use(BootstrapVue)
  import 'bootstrap/dist/css/bootstrap.css'
  import 'bootstrap-vue/dist/bootstrap-vue.css'
  import CommentGrid from './components/CommentGrid.vue';
  import NewComment from './components/NewComment.vue';

  export default {
      data: function() {
        return {
          comments: [
            'Comentário padrão',
          ],
          maxComments: 999
        }
      },
     methods: {
        newComment(comment) {
            this.comments.push(comment);
        },
      },
      components: {
        appCommentGrid: CommentGrid,
        appNewComment: NewComment,
      }
  }
</script>

<style>

</style>
